
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:onlinecourse/screen/page_40_mycourse.dart';
import 'package:onlinecourse/screen/page_43_Inbox.dart';
import 'package:onlinecourse/screen/page_47_Transactions.dart';
import 'package:onlinecourse/screen/page_50_profile.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    // Create a MaterialColor with white as its primary color
    MaterialColor whiteMaterialColor = MaterialColor(0xFFFFFFFF, {
      50: Colors.white,
      100: Colors.white,
      200: Colors.white,
      300: Colors.white,
      400: Colors.white,
      500: Colors.white,
      600: Colors.white,
      700: Colors.white,
      800: Colors.white,
      900: Colors.white,
    });

    return MaterialApp(
      title: 'OnlineCourse',

      initialRoute: '/profile', // Set the initial route to the inbox page
      routes: {
        '/home': (context) =>  MyCourseLessons(),
        '/mycourses': (context) => CoursesPageContent(),
        '/inbox': (context) => PageInboxChat(),
        '/transaction': (context) => PageTransaction(),
        '/profile': (context) => PageProfile(),
      },

      theme: ThemeData(
        colorScheme: ColorScheme.fromSwatch(primarySwatch: whiteMaterialColor), // Set seed color to white
        useMaterial3: true,
 
        scaffoldBackgroundColor: const Color(0xFFF5F9FF), // Set background color
      ),
      // home: const PageMyCourseLessons(),
      debugShowCheckedModeBanner: false,
    );
  }
}